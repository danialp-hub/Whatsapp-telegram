
const express = require("express");
const axios = require("axios");
const fs = require("fs");
const path = require("path");

const app = express();
app.use(express.json());

const VERIFY_TOKEN = process.env.VERIFY_TOKEN || "alma123";
const TELEGRAM_TOKEN = process.env.TELEGRAM_TOKEN;
const TELEGRAM_CHAT_ID = process.env.TELEGRAM_CHAT_ID;
const WHATSAPP_TOKEN = process.env.WHATSAPP_TOKEN;
const PHONE_NUMBER_ID = process.env.PHONE_NUMBER_ID;

const LEADS_FILE = path.join(__dirname, "leads.json");
const LISTS_DIR = path.join(__dirname, "broadcast_lists");

const DEFAULT_BROADCAST_LIMIT = Number(process.env.DEFAULT_BROADCAST_LIMIT || 250);
const BROADCAST_DELAY_MS = Number(process.env.BROADCAST_DELAY_MS || 2500);

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function normalizePhoneForWhatsApp(value) {
  let phone = String(value || "").trim();
  phone = phone.replace(/\s+/g, "");
  phone = phone.replace(/[^\d+]/g, "");
  if (phone.startsWith("+")) phone = phone.slice(1);
  if (phone.startsWith("00")) phone = phone.slice(2);
  return phone;
}

function readLeads() {
  try {
    if (!fs.existsSync(LEADS_FILE)) {
      fs.writeFileSync(LEADS_FILE, JSON.stringify([], null, 2));
    }
    return JSON.parse(fs.readFileSync(LEADS_FILE, "utf8") || "[]");
  } catch (error) {
    console.error("Read leads error:", error.message);
    return [];
  }
}

function saveLead(phone, message) {
  try {
    const leads = readLeads();
    leads.push({ phone, message, date: new Date().toISOString() });
    fs.writeFileSync(LEADS_FILE, JSON.stringify(leads, null, 2));
    console.log("Lead saved:", phone, message);
  } catch (error) {
    console.error("Save lead error:", error.message);
  }
}

function getLeadsText() {
  const leads = readLeads();
  if (!leads || leads.length === 0) return "No leads saved yet.";
  const lastLeads = leads.slice(-20).reverse();
  return `📋 Last ${lastLeads.length} Leads:\n\n` + lastLeads.map((lead, index) =>
    `${index + 1}. ${lead.phone}\n💬 ${lead.message}\n🕒 ${lead.date}`
  ).join("\n\n");
}

async function sendTelegram(text) {
  if (!TELEGRAM_TOKEN || !TELEGRAM_CHAT_ID) return;
  await axios.post(`https://api.telegram.org/bot${TELEGRAM_TOKEN}/sendMessage`, {
    chat_id: TELEGRAM_CHAT_ID,
    text,
  });
}

async function sendWhatsAppText(to, text) {
  await axios.post(
    `https://graph.facebook.com/v25.0/${PHONE_NUMBER_ID}/messages`,
    {
      messaging_product: "whatsapp",
      to: normalizePhoneForWhatsApp(to),
      type: "text",
      text: { body: text },
    },
    {
      headers: {
        Authorization: `Bearer ${WHATSAPP_TOKEN}`,
        "Content-Type": "application/json",
      },
    }
  );
}

async function sendWhatsAppTemplate(to, templateName, languageCode = "en") {
  await axios.post(
    `https://graph.facebook.com/v25.0/${PHONE_NUMBER_ID}/messages`,
    {
      messaging_product: "whatsapp",
      to: normalizePhoneForWhatsApp(to),
      type: "template",
      template: {
        name: templateName,
        language: { code: languageCode },
      },
    },
    {
      headers: {
        Authorization: `Bearer ${WHATSAPP_TOKEN}`,
        "Content-Type": "application/json",
      },
    }
  );
}

function extractPhoneFromTelegramMessage(text) {
  if (!text) return null;
  const match = text.match(/From:\s*(\d+)/i);
  if (match && match[1]) return match[1];
  const fallback = text.match(/\b\d{8,15}\b/);
  if (fallback && fallback[0]) return fallback[0];
  return null;
}

function getAvailableLists() {
  if (!fs.existsSync(LISTS_DIR)) return [];
  return fs.readdirSync(LISTS_DIR)
    .filter((file) => file.toLowerCase().endsWith(".csv"))
    .map((file) => file.replace(/\.csv$/i, ""));
}

function readBroadcastList(listName) {
  const safeName = String(listName || "").replace(/[^\w.-]/g, "");
  const filePath = path.join(LISTS_DIR, `${safeName}.csv`);
  if (!fs.existsSync(filePath)) throw new Error(`List not found: ${safeName}`);

  const raw = fs.readFileSync(filePath, "utf8");
  const phones = raw.split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean)
    .filter((line) => line.toLowerCase() !== "phone")
    .map((line) => normalizePhoneForWhatsApp(line.split(",")[0]))
    .filter((phone) => phone.length >= 8 && phone.length <= 15);

  return [...new Set(phones)];
}

async function runBroadcast(listName, templateName, limit) {
  const phones = readBroadcastList(listName).slice(0, limit);
  let success = 0;
  let failed = 0;
  const failedNumbers = [];

  await sendTelegram(`🚀 Broadcast started\n\nList: ${listName}\nTemplate: ${templateName}\nTotal: ${phones.length}\nDelay: ${BROADCAST_DELAY_MS} ms`);

  for (let i = 0; i < phones.length; i++) {
    const phone = phones[i];

    try {
      await sendWhatsAppTemplate(phone, templateName, "en");
      success++;
      console.log(`[Broadcast] Sent ${i + 1}/${phones.length}: ${phone}`);
    } catch (error) {
      failed++;
      failedNumbers.push(phone);
      console.error(`[Broadcast] Failed ${phone}:`, error.response?.data || error.message);
    }

    if ((i + 1) % 25 === 0) {
      await sendTelegram(`📊 Broadcast progress\n\nList: ${listName}\nDone: ${i + 1}/${phones.length}\nSuccess: ${success}\nFailed: ${failed}`);
    }

    await sleep(BROADCAST_DELAY_MS);
  }

  let report = `✅ Broadcast finished\n\nList: ${listName}\nTemplate: ${templateName}\nSuccess: ${success}\nFailed: ${failed}`;
  if (failedNumbers.length > 0) {
    report += `\n\nFailed numbers:\n${failedNumbers.slice(0, 20).join("\n")}`;
    if (failedNumbers.length > 20) report += `\n...and ${failedNumbers.length - 20} more`;
  }

  await sendTelegram(report);
}

app.get("/", (req, res) => {
  res.send("ALMA DXB WhatsApp Telegram Bot Running");
});

app.get("/webhook", (req, res) => {
  const mode = req.query["hub.mode"];
  const token = req.query["hub.verify_token"];
  const challenge = req.query["hub.challenge"];
  if (mode === "subscribe" && token === VERIFY_TOKEN) return res.status(200).send(challenge);
  return res.sendStatus(403);
});

app.post("/telegram", async (req, res) => {
  try {
    const message = req.body?.message;
    const text = message?.text || "";
    if (!message || !text) return res.sendStatus(200);

    if (message.reply_to_message && !text.startsWith("/")) {
      const phone = extractPhoneFromTelegramMessage(message.reply_to_message.text || "");
      if (!phone) {
        await sendTelegram("❌ Could not find customer phone number in replied message.");
        return res.sendStatus(200);
      }
      await sendWhatsAppText(phone, text);
      await sendTelegram(`✅ Reply sent to WhatsApp:\n${phone}\n\n${text}`);
      return res.sendStatus(200);
    }

    if (text === "/start" || text === "/help") {
      await sendTelegram(`ALMA DXB Bot is active ✅\n\nCommands:\n/leads\n/lists\n/broadcast LIST_NAME TEMPLATE_NAME\n/broadcast LIST_NAME TEMPLATE_NAME LIMIT\n/send 971501234567 Your message here\n\nExamples:\n/broadcast Iran_Part1 alma_text 100\n/broadcast Iran_Part2 alma_text 250\n/broadcast Other alma_text 50`);
      return res.sendStatus(200);
    }

    if (text === "/leads") {
      await sendTelegram(getLeadsText());
      return res.sendStatus(200);
    }

    if (text === "/lists") {
      const lists = getAvailableLists();
      await sendTelegram(lists.length ? `📂 Available broadcast lists:\n\n${lists.join("\n")}` : "No broadcast lists found.");
      return res.sendStatus(200);
    }

    if (text.startsWith("/broadcast ")) {
      const parts = text.split(" ");
      const listName = parts[1];
      const templateName = parts[2] || "alma_text";
      const requestedLimit = Number(parts[3] || DEFAULT_BROADCAST_LIMIT);
      const limit = Math.min(requestedLimit, DEFAULT_BROADCAST_LIMIT);

      if (!listName || !templateName) {
        await sendTelegram("❌ Wrong format.\n\nUse:\n/broadcast Iran_Part1 alma_text 100");
        return res.sendStatus(200);
      }

      res.sendStatus(200);
      runBroadcast(listName, templateName, limit).catch(async (error) => {
        console.error("Broadcast Error:", error.response?.data || error.message);
        await sendTelegram(`❌ Broadcast error:\n${error.response?.data?.error?.message || error.message}`);
      });
      return;
    }

    if (text.startsWith("/send ")) {
      const parts = text.split(" ");
      const phone = parts[1];
      const replyText = parts.slice(2).join(" ");
      if (!phone || !replyText) {
        await sendTelegram("❌ Wrong format.\n\nUse:\n/send 971501234567 Your message here");
        return res.sendStatus(200);
      }
      await sendWhatsAppText(phone, replyText);
      await sendTelegram(`✅ Sent to WhatsApp:\n${phone}\n\n${replyText}`);
      return res.sendStatus(200);
    }

    await sendTelegram("Unknown command. Use /help");
    return res.sendStatus(200);
  } catch (error) {
    console.error("Telegram Error:", error.response?.data || error.message);
    return res.sendStatus(500);
  }
});

app.post("/webhook", async (req, res) => {
  try {
    const value = req.body?.entry?.[0]?.changes?.[0]?.value;
    const message = value?.messages?.[0];
    if (!message) return res.sendStatus(200);

    const from = message.from;
    const text = message.text?.body || "[Non-text message]";

    console.log(`Message from ${from}: ${text}`);
    saveLead(from, text);
    await sendTelegram(`📱 WhatsApp Message\n\n👤 From: ${from}\n💬 ${text}`);

    const lowerText = text.toLowerCase();
    if (lowerText.includes("catalog") || lowerText.includes("list") || lowerText.includes("price") || lowerText.includes("offer")) {
      const catalog = `📢 ALMA DXB – JUNE 2026 CATALOG\n\n🎧 Anker Soundcore\n• R50i – 31.50 AED\n• V20i – 52 AED\n• R60i – 69.50 AED\n• R50i NC – 51 AED\n• K20i – 31 AED\n• C50i – 130 AED\n• V40i – 130 AED\n• Liberty Buds – 220 AED\n\n📍 ALMA DXB\n📲 WhatsApp: +971 55 140 0474`;
      await sendWhatsAppText(from, catalog);
    } else if (lowerText.includes("hi") || lowerText.includes("hello") || lowerText.includes("سلام")) {
      const reply = `Hello 👋\n\nThank you for contacting ALMA DXB.\n\nFor our latest product catalog and offers, please reply with:\n\nCATALOG\n\n📍 ALMA DXB\n📲 WhatsApp: +971 55 140 0474`;
      await sendWhatsAppText(from, reply);
    }

    return res.sendStatus(200);
  } catch (error) {
    console.error("Webhook Error:", error.response?.data || error.message);
    return res.sendStatus(500);
  }
});

const PORT = process.env.PORT || 10000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
